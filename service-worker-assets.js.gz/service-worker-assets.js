self.assetsManifest = {
  "version": "ASjzU3qD",
  "assets": [
    {
      "hash": "sha256-7zvpOkHAG37EEaDvIF07w10O6UytTPkLdLnyrIEJG9U=",
      "url": "MyCarApp.Client.styles.css"
    },
    {
      "hash": "sha256-kJXKqRCleT/Jk1wJUhUu24r2LAA7IWVYmdoENizE38M=",
      "url": "_content/Microsoft.AspNetCore.Components.WebAssembly.Authentication/AuthenticationService.js"
    },
    {
      "hash": "sha256-JMtq+OQ6SYO1AZNbPIO06cnbqYKQuGZ2Ap8bSbYF5Rs=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.c8z6dobcnr.wasm"
    },
    {
      "hash": "sha256-AMJMNSz5FNyu0ZWxKCF2B2ywfLaA9TnwrDlGF+xCmFE=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.cte4yqt1hg.wasm"
    },
    {
      "hash": "sha256-ZM2jjBjMB6nYiuZnzE43dBTfeV/sFzNag3IoP310gmk=",
      "url": "_framework/Microsoft.AspNetCore.Components.cw92o700p8.wasm"
    },
    {
      "hash": "sha256-TRP7en/tYrB0OHj3n5BVZ5BQH3VTIuLi7/i+WeKRXyM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.h3x7gkd3wi.wasm"
    },
    {
      "hash": "sha256-VMrWC8sWoLTG7hDHK/Ayv1YL17beJdSbieuySCjz7zY=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.kaj8eppjjq.wasm"
    },
    {
      "hash": "sha256-SetdHnoubSXEfLfgohBpm7QWFpANyybYdHUQHXJmcGQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.zdophn6obr.wasm"
    },
    {
      "hash": "sha256-DcWkDb7zkUlhH7MB9IBcDIzrkmTv5eptjU51yJuC0zw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.dwgyfnlzcr.wasm"
    },
    {
      "hash": "sha256-FLbHGpks/qUdpolOZxXwNFFHSZ2+KaN0l03L22jlZOw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.sa5hpai13s.wasm"
    },
    {
      "hash": "sha256-xA+ytRrbaOekVVhTbicKSVXXNG4cbmDKJd4lNLvP8f8=",
      "url": "_framework/Microsoft.Extensions.Logging.4664kl3vo3.wasm"
    },
    {
      "hash": "sha256-i+GrcKouCYCzpa+6zvqtJ/y9SbjWW3IrijV6cEIg7iM=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.pfsiadelql.wasm"
    },
    {
      "hash": "sha256-+27eWNMmLa955NfHFW65RZmf9WBtJKmWW4u2fcWrysw=",
      "url": "_framework/Microsoft.Extensions.Options.vvsb451hhm.wasm"
    },
    {
      "hash": "sha256-Ycz+w9nHNejmoGby5JGWA0ngKY8AzwRkSE1Cp8kjQGE=",
      "url": "_framework/Microsoft.Extensions.Primitives.3z3yjm2nul.wasm"
    },
    {
      "hash": "sha256-AKlxBNSGgaujQlZBLHCptAZb8WnLxhfrMDpXYlXsvvo=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.s5f1glpht3.wasm"
    },
    {
      "hash": "sha256-PY34irsjw58HnvK+lqLcyZs3i91TME047wJ2a7YKlrY=",
      "url": "_framework/Microsoft.JSInterop.p9qd3x0jse.wasm"
    },
    {
      "hash": "sha256-RlQLcfyloK9qyMuu4PZ/7AKy2b8cR8+eXfo9w2H6xMU=",
      "url": "_framework/MyCarApp.Client.euc1doxn5o.wasm"
    },
    {
      "hash": "sha256-DuFChWgNE5Jy8YTZaN5f3B7ZFUsNlxHHgqBtijA83RY=",
      "url": "_framework/System.Collections.6ud4qi6y7c.wasm"
    },
    {
      "hash": "sha256-17OdZiWxlN2U93TJJVsN/+gZ1gJ2bkvWc8lh6tAQLOs=",
      "url": "_framework/System.Collections.Concurrent.lhnl6vkgq1.wasm"
    },
    {
      "hash": "sha256-pLBocza4/T8PaMJOVabXpTT6du3ORT9Lp6k9t/KF0Ow=",
      "url": "_framework/System.Collections.Immutable.057ik266m0.wasm"
    },
    {
      "hash": "sha256-CR76GIDDw1MfCthwQyrZZq4JBsRxEB1vPmliVD9HL4U=",
      "url": "_framework/System.ComponentModel.xmxjt0ntly.wasm"
    },
    {
      "hash": "sha256-4a8oiTIMzmaEyRt1ybWZX9DBQu5SuRMSE3kMJq0dk+Y=",
      "url": "_framework/System.Console.nyg5vrq8o6.wasm"
    },
    {
      "hash": "sha256-Cgkv0P5nJWOjy/4Dh7/xIh6jdl4G/PIytybV6ZgWi8Y=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.mkxci42bp7.wasm"
    },
    {
      "hash": "sha256-icS8WxKQ4KAWcutc7rR8xAIOabkTt6riZJOoYooT3/k=",
      "url": "_framework/System.IO.Pipelines.pwfw0zwx98.wasm"
    },
    {
      "hash": "sha256-CJ92JOA6TMlQLuihrYfPIsr09UXynuHdmkWybRoeBDM=",
      "url": "_framework/System.Linq.0i0e1haing.wasm"
    },
    {
      "hash": "sha256-cw1Q+xuaULAZWcpsdFyDwDYvD7U9Gvnxe0R+qERw/I8=",
      "url": "_framework/System.Memory.rilmbzyyhn.wasm"
    },
    {
      "hash": "sha256-+sa2oBF2EJW9WAG8xC58/DDmHL69LpupX5i8/8p/SYM=",
      "url": "_framework/System.Net.Http.6w88ao32m9.wasm"
    },
    {
      "hash": "sha256-CUovBg23NaoRjuALk46lBGTpxmWlKi9MYuNgMAPQsxg=",
      "url": "_framework/System.Net.Http.Json.hu81bv2ep7.wasm"
    },
    {
      "hash": "sha256-uRlmBIaMHzcgdgYHMFo8VXhqVUAViuHIXE8c8Ub4XAw=",
      "url": "_framework/System.Net.Primitives.xmwuhmteav.wasm"
    },
    {
      "hash": "sha256-PbfdPqxZUdMi9u2WgRcoEaf/LRbwaUniY44ku6Mzq/g=",
      "url": "_framework/System.Private.CoreLib.pdlgjtqvl0.wasm"
    },
    {
      "hash": "sha256-f09+mcRmRdq7w5RXQiojJHQZpM2/EQIy9dPzlLRXbKg=",
      "url": "_framework/System.Private.Uri.d1xhz3gcw2.wasm"
    },
    {
      "hash": "sha256-p6/wV05PEoKocillIiVPYCnVVIrkHEzHoyxRM/6Uc8A=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.hq2mpklnqr.wasm"
    },
    {
      "hash": "sha256-fZhuBJYqtk21XIRC30d3erkWXet70LjAU2EjHEb8bFk=",
      "url": "_framework/System.Runtime.jssrxbdo5n.wasm"
    },
    {
      "hash": "sha256-5STuuzqiWrDJm62Lw4UYwqJ73iHHx4OxypqBOqHCKqg=",
      "url": "_framework/System.Security.Cryptography.vv6xqw2hzq.wasm"
    },
    {
      "hash": "sha256-FeyOc5aMuRZQlnW8yv053DDkUoap+mfDnDZ81Wus+wA=",
      "url": "_framework/System.Text.Encodings.Web.5g1jewtpp1.wasm"
    },
    {
      "hash": "sha256-pJYu3bdHCkuUfvMBubI5Jkei6oEtFzETBwWO2rqSzTs=",
      "url": "_framework/System.Text.Json.gfrqcc63i5.wasm"
    },
    {
      "hash": "sha256-RKsWZUssDB/RXTQKl8L9d2RkU07BE1vcJyMUa4kULZ4=",
      "url": "_framework/System.Text.RegularExpressions.0vmwpkdzue.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.66stpp682q.js"
    },
    {
      "hash": "sha256-2lvfACsds38yB7F9BvnIUtb0JBZIjimRTjlFpr4MLSw=",
      "url": "_framework/dotnet.native.imnhyiqpc9.wasm"
    },
    {
      "hash": "sha256-tlrn00yvndmJzhFdKpELUlytdgWFyGFdTWjI10bgILU=",
      "url": "_framework/dotnet.native.mx9wzm9o5h.js"
    },
    {
      "hash": "sha256-/ndm/PF1BeBT5mXzYAES79wNK5sIZIQKAGcUqPL9ZP8=",
      "url": "_framework/dotnet.runtime.2zl32tp6ah.js"
    },
    {
      "hash": "sha256-7T/aINxSRgpIxgu/WtdmIqmkHpXohnn2g7nH0Q+/A20=",
      "url": "_framework/dotnet.t8b8tyhh1k.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-wjtvo+upmrKjo3zjjZzv98CdnFN7e5zU0/ylsCaUQ2Y=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-QTDGAeIr65FZYIJEQUtq1JmIozr5f3d3UhNb/cT2zHM=",
      "url": "index.html"
    },
    {
      "hash": "sha256-des2w1vQ1qcbPixXQXsAJthKR1rH0JBGUwlFCEoW2nQ=",
      "url": "js/export.js"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-uMkI/0kD9VWemt2MuXCociqykifdwpaQ4spFQpO873Q=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-dvI5jormDxxGzSgUzIq+0CvpUWOUi10Hhk0TJnbmLI4=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-gaEefLjpu4vxO3N6bH59dVvg0sp3q4ep3BAl1ePg3Gg=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-qJ113/Jv4hQYFv/ji7x7PIbOvL6apkUf7zDMZrHoTg4=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-URMvxBXoaxIxKLqmWz4Fko2eHLAmD55I8MS2gtP0Rug=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-meiBFOJz7M5GeXWUvbw14vdGD0ehYneQCmQZHolxv6o=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-2tZUYQmsPZFYnnpqYrsiViFVenatlVAQmIUTNWH5zbk=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-xqHhcm69Nn1wIL9g8Z/PE7qhYJat0uRgM2In1Vb7EFE=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-KKdFepldoOW1RsQocJ3Gwe29VNxGfOdJVCQNDSHyYeA=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-OO0moYHBMylfBNcYkv7tWWcRIOE6vzsV2zdcchGeEns=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-paIeuWnSzjeLGITWkk4p3rcejUsZWCJGPeOK9UhWXtg=",
      "url": "sample-data/weather.json"
    }
  ]
};
